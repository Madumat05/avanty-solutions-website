"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { SplashScreen } from "@/components/splash-screen"
import { Starfield } from "@/components/starfield"
import { AnimatedSection } from "@/components/animated-section"
import { ROICalculator } from "@/components/roi-calculator"
import { AnimatedCounter } from "@/components/animated-counter"
import { ProcessTimeline } from "@/components/process-timeline"
import {
  Settings,
  Database,
  TrendingUp,
  Workflow,
  Instagram,
  Mail,
  MessageCircle,
  ChevronDown,
  ArrowRight,
  Layers,
  Zap,
  BarChart3,
  Clock,
  Target,
  Rocket,
  CheckCircle2,
  Menu,
  X,
} from "lucide-react"
import Image from "next/image"
import { useState } from "react"

export default function AvantyPage() {
  const [copiedEmail, setCopiedEmail] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const copyEmail = () => {
    navigator.clipboard.writeText("contato.avantysolutions@gmail.com")
    setCopiedEmail(true)
    setTimeout(() => setCopiedEmail(false), 2000)
  }

  return (
    <>
      <SplashScreen />

      <div className="min-h-screen bg-background text-foreground">
        <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/30 bg-background/80 backdrop-blur-xl transition-all">
          <div className="container mx-auto flex items-center justify-between px-4 md:px-6 py-3 md:py-4">
            <div className="flex items-center gap-2">
              <div className="relative h-8 w-8 md:h-10 md:w-10">
                <Image src="/logo.png" alt="Avanty Solutions" fill className="object-contain" priority />
              </div>
              <span className="text-lg md:text-xl font-bold">Avanty Solutions</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-6 xl:gap-8">
              <a
                href="#trabalho"
                className="text-sm text-muted-foreground transition-all hover:text-foreground hover:scale-105"
              >
                Nosso Trabalho
              </a>
              <a
                href="#servicos"
                className="text-sm text-muted-foreground transition-all hover:text-foreground hover:scale-105"
              >
                Serviços
              </a>
              <a
                href="#sobre"
                className="text-sm text-muted-foreground transition-all hover:text-foreground hover:scale-105"
              >
                Sobre Nós
              </a>
              <a
                href="#faq"
                className="text-sm text-muted-foreground transition-all hover:text-foreground hover:scale-105"
              >
                FAQ
              </a>
              <a
                href="#contato"
                className="text-sm text-muted-foreground transition-all hover:text-foreground hover:scale-105"
              >
                Contato
              </a>
            </div>

            <div className="flex items-center gap-3">
              <Button
                asChild
                size="sm"
                className="hidden md:flex group bg-primary text-primary-foreground hover:bg-primary/90 transition-all hover:scale-105 hover:shadow-lg hover:shadow-primary/20"
              >
                <a href="https://wa.me/5531975019782" target="_blank" rel="noopener noreferrer">
                  Agendar Conversa
                </a>
              </Button>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-foreground"
                aria-label="Toggle menu"
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden border-t border-border/30 bg-background/95 backdrop-blur-xl">
              <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
                <a
                  href="#trabalho"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors py-2"
                >
                  Nosso Trabalho
                </a>
                <a
                  href="#servicos"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors py-2"
                >
                  Serviços
                </a>
                <a
                  href="#sobre"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors py-2"
                >
                  Sobre Nós
                </a>
                <a
                  href="#faq"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors py-2"
                >
                  FAQ
                </a>
                <a
                  href="#contato"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors py-2"
                >
                  Contato
                </a>
                <Button asChild size="sm" className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                  <a href="https://wa.me/5531975019782" target="_blank" rel="noopener noreferrer">
                    Agendar Conversa
                  </a>
                </Button>
              </div>
            </div>
          )}
        </nav>

        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16 md:pt-20">
          <Starfield />

          <div className="container relative z-10 mx-auto px-4 md:px-6">
            <div className="mx-auto max-w-5xl text-center">
              <div className="mb-4 md:mb-6 inline-block rounded-full border border-primary/30 bg-primary/10 px-4 md:px-6 py-1.5 md:py-2 text-xs md:text-sm font-medium text-primary animate-fade-in backdrop-blur-sm">
                🚀 Transformação Digital com IA
              </div>

              <h1 className="mb-6 md:mb-8 text-3xl sm:text-4xl md:text-5xl lg:text-7xl xl:text-8xl font-bold leading-tight text-balance animate-slide-up px-4">
                Liberte sua equipe do operacional. <span className="text-primary">Foque no estratégico.</span>
              </h1>

              <p className="mb-8 md:mb-12 text-base md:text-xl lg:text-2xl text-muted-foreground text-pretty max-w-3xl mx-auto animate-slide-up-delayed px-4">
                Transformamos processos confusos e repetitivos em ecossistemas inteligentes com IA, liberando você e sua
                equipe para focar no que realmente faz o negócio crescer.
              </p>

              <div className="mb-8 md:mb-12 flex flex-wrap items-center justify-center gap-4 md:gap-8 opacity-60 animate-fade-in-slow px-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 md:h-5 md:w-5 text-primary flex-shrink-0" />
                  <span className="text-xs md:text-sm text-muted-foreground">Implementação em 12 dias</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 md:h-5 md:w-5 text-primary flex-shrink-0" />
                  <span className="text-xs md:text-sm text-muted-foreground">Garantia de 30 dias</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 md:h-5 md:w-5 text-primary flex-shrink-0" />
                  <span className="text-xs md:text-sm text-muted-foreground">ROI mensurável</span>
                </div>
              </div>

              <div className="animate-fade-in-slow px-4">
                <Button
                  size="lg"
                  asChild
                  className="group bg-primary text-primary-foreground hover:bg-primary/90 transition-all text-base md:text-lg px-6 md:px-8 py-5 md:py-6 h-auto hover:scale-105 hover:shadow-2xl hover:shadow-primary/30 w-full sm:w-auto"
                >
                  <a href="https://wa.me/5531975019782" target="_blank" rel="noopener noreferrer">
                    Agende uma Análise Gratuita
                    <ArrowRight className="ml-2 h-4 w-4 md:h-5 md:w-5 transition-transform group-hover:translate-x-1" />
                  </a>
                </Button>
              </div>

              <div className="mt-12 md:mt-20 animate-bounce-slow">
                <ChevronDown className="h-6 w-6 md:h-8 md:w-8 mx-auto text-muted-foreground" />
              </div>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-16 bg-gradient-to-b from-transparent to-primary/5">
          <div className="container mx-auto px-4 md:px-6">
            <AnimatedSection>
              <div className="grid gap-8 md:gap-12 md:grid-cols-3 max-w-5xl mx-auto text-center">
                <div className="flex flex-col items-center">
                  <AnimatedCounter
                    end={70}
                    suffix="%"
                    className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary mb-2"
                  />
                  <p className="text-sm md:text-base text-muted-foreground">Redução de Custos Operacionais</p>
                </div>
                <div className="flex flex-col items-center">
                  <AnimatedCounter
                    end={12}
                    suffix=" dias"
                    className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary mb-2"
                  />
                  <p className="text-sm md:text-base text-muted-foreground">Tempo Médio de Implementação</p>
                </div>
                <div className="flex flex-col items-center">
                  <AnimatedCounter
                    end={24}
                    suffix="/7"
                    className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary mb-2"
                  />
                  <p className="text-sm md:text-base text-muted-foreground">Operação Contínua com IA</p>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <section id="trabalho" className="py-16 md:py-24 bg-gradient-to-b from-primary/5 to-transparent">
          <div className="container mx-auto px-4 md:px-6">
            <AnimatedSection className="mb-12 md:mb-20 text-center">
              <h2 className="mb-4 md:mb-6 text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold">
                Soluções que <span className="text-primary">Transformam</span>
              </h2>
              <p className="mx-auto max-w-3xl text-base md:text-xl text-muted-foreground px-4">
                Ecossistemas inteligentes personalizados para o seu setor.
              </p>
            </AnimatedSection>

            <div className="grid gap-6 md:gap-8 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
              <AnimatedSection delay={100}>
                <Card className="group border-border/30 bg-card/30 backdrop-blur-sm transition-all duration-300 hover:border-primary/50 hover:scale-105 hover:shadow-xl hover:shadow-primary/10 h-full">
                  <CardContent className="p-8">
                    <div className="mb-6 flex gap-4 text-muted-foreground transition-colors group-hover:text-primary">
                      <Settings className="h-8 w-8" />
                      <Zap className="h-8 w-8" />
                    </div>
                    <h3 className="mb-4 text-2xl font-bold">
                      <span className="text-primary">Agentes de IA</span>
                    </h3>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      Automação inteligente para atendimento, suporte, vendas e qualificação de leads. Nossos agentes de
                      IA trabalham 24/7, reduzindo custos operacionais em até 70% e aumentando a taxa de conversão.
                    </p>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>Atendimento instantâneo 24/7</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>Qualificação automática de leads</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>Integração com CRM e sistemas</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </AnimatedSection>

              <AnimatedSection delay={200}>
                <Card className="group border-border/30 bg-card/30 backdrop-blur-sm transition-all duration-300 hover:border-primary/50 hover:scale-105 hover:shadow-xl hover:shadow-primary/10 h-full">
                  <CardContent className="p-8">
                    <div className="mb-6 flex gap-4 text-muted-foreground transition-colors group-hover:text-primary">
                      <Workflow className="h-8 w-8" />
                      <Database className="h-8 w-8" />
                    </div>
                    <h3 className="mb-4 text-2xl font-bold">
                      <span className="text-primary">Automação de Fluxos</span>
                    </h3>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      Elimine tarefas manuais e ganhe agilidade operacional. Integramos seus sistemas (CRM, ERP,
                      planilhas) garantindo processos fluidos, precisos e totalmente automatizados.
                    </p>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>Integração entre sistemas</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>Automação de relatórios</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>Redução de erros humanos</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </AnimatedSection>

              <AnimatedSection delay={300}>
                <Card className="group border-border/30 bg-card/30 backdrop-blur-sm transition-all duration-300 hover:border-primary/50 hover:scale-105 hover:shadow-xl hover:shadow-primary/10 h-full">
                  <CardContent className="p-8">
                    <div className="mb-6 flex gap-4 text-muted-foreground transition-colors group-hover:text-primary">
                      <TrendingUp className="h-8 w-8" />
                      <BarChart3 className="h-8 w-8" />
                    </div>
                    <h3 className="mb-4 text-2xl font-bold">
                      <span className="text-primary">Consultoria Estratégica</span>
                    </h3>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      Desbloqueie o verdadeiro potencial da IA no seu negócio. Analisamos seus processos e identificamos
                      oportunidades para redução de custos, aumento de produtividade e escalabilidade sustentável.
                    </p>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>Análise de processos</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>Roadmap de implementação</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>Acompanhamento de resultados</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </AnimatedSection>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24 bg-gradient-to-b from-transparent via-primary/5 to-transparent">
          <div className="container mx-auto px-4 md:px-6">
            <AnimatedSection className="mb-12 md:mb-20 text-center">
              <h2 className="mb-4 md:mb-6 text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold">
                Como <span className="text-primary">Funciona</span>
              </h2>
              <p className="mx-auto max-w-3xl text-base md:text-xl text-muted-foreground px-4">
                Um processo simples e transparente para transformar seu negócio
              </p>
            </AnimatedSection>

            <AnimatedSection delay={100}>
              <ProcessTimeline />
            </AnimatedSection>
          </div>
        </section>

        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4 md:px-6">
            
          </div>
        </section>

        <section id="servicos" className="py-16 md:py-24 bg-gradient-to-b from-transparent to-primary/5">
          <div className="container mx-auto px-4 md:px-6">
            <AnimatedSection className="mb-12 md:mb-20 text-center">
              <h2 className="mb-4 md:mb-6 text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold">
                Por que escolher a <span className="text-primary">Avanty</span>?
              </h2>
              <p className="mx-auto max-w-3xl text-base md:text-xl text-muted-foreground px-4">
                Implementar IA nos processos da sua empresa gera ganhos imediatos e duradouros
              </p>
            </AnimatedSection>

            <div className="grid gap-8 md:gap-12 lg:gap-16 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
              <AnimatedSection delay={100} className="text-center">
                <div className="mb-6 inline-flex h-20 w-20 items-center justify-center transition-transform hover:scale-110">
                  <Layers className="h-16 w-16 text-muted-foreground" />
                </div>
                <h3 className="mb-4 text-2xl font-bold">Escalabilidade Real</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Cresça sem aumentar custos proporcionalmente. Nossas soluções escalam com seu negócio, permitindo
                  crescimento sustentável e previsível.
                </p>
              </AnimatedSection>

              <AnimatedSection delay={200} className="text-center">
                <div className="mb-6 inline-flex h-20 w-20 items-center justify-center transition-transform hover:scale-110">
                  <Zap className="h-16 w-16 text-muted-foreground" />
                </div>
                <h3 className="mb-4 text-2xl font-bold">Eficiência Comprovada</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Reduza tempo de execução em até 80% automatizando processos repetitivos. Resultados mensuráveis desde
                  o primeiro mês.
                </p>
              </AnimatedSection>

              <AnimatedSection delay={300} className="text-center">
                <div className="mb-6 inline-flex h-20 w-20 items-center justify-center transition-transform hover:scale-110">
                  <BarChart3 className="h-16 w-16 text-muted-foreground" />
                </div>
                <h3 className="mb-4 text-2xl font-bold">ROI Transparente</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Acompanhe métricas claras e veja o retorno sobre investimento das automações implementadas em tempo
                  real através de dashboards personalizados.
                </p>
              </AnimatedSection>
            </div>
          </div>
        </section>

        <section id="sobre" className="py-16 md:py-24 bg-gradient-to-b from-transparent via-primary/5 to-transparent">
          <div className="container mx-auto px-4 md:px-6">
            <AnimatedSection className="mx-auto max-w-4xl text-center">
              <h2 className="mb-6 md:mb-8 text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold">
                Sobre <span className="text-primary">Nós</span>
              </h2>

              <div className="mb-8 md:mb-12 rounded-2xl border border-border/30 bg-card/20 backdrop-blur-sm p-6 md:p-12 transition-all hover:border-primary/30 hover:shadow-xl hover:shadow-primary/5">
                <p className="text-base md:text-xl lg:text-2xl leading-relaxed text-foreground/90 text-left">
                  Na Avanty, não entregamos apenas tecnologia — entregamos{" "}
                  <span className="font-bold text-primary">tempo, liberdade e resultados reais</span>. Somos uma agência
                  de automação e IA que atua como parceira estratégica, entendendo os desafios do seu dia a dia. Cada
                  solução é personalizada, mensurável e feita sob medida para destravar processos, aumentar
                  produtividade e escalar seu negócio de forma sustentável.
                </p>
              </div>

              <Button
                size="lg"
                asChild
                className="group bg-primary text-primary-foreground hover:bg-primary/90 transition-all text-base md:text-lg px-6 md:px-8 py-5 md:py-6 h-auto hover:scale-105 hover:shadow-2xl hover:shadow-primary/30 w-full sm:w-auto"
              >
                <a href="https://wa.me/5531975019782" target="_blank" rel="noopener noreferrer">
                  Descobrir Soluções
                  <ArrowRight className="ml-2 h-4 w-4 md:h-5 md:w-5 transition-transform group-hover:translate-x-1" />
                </a>
              </Button>
            </AnimatedSection>
          </div>
        </section>

        <section id="faq" className="py-16 md:py-24">
          <div className="container mx-auto px-4 md:px-6">
            <div className="mx-auto max-w-3xl">
              <AnimatedSection>
                <h2 className="mb-12 md:mb-16 text-center text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold">
                  Dúvidas Frequentes
                </h2>
              </AnimatedSection>

              <AnimatedSection delay={100}>
                <Accordion type="single" collapsible className="space-y-4">
                  <AccordionItem
                    value="item-1"
                    className="rounded-lg border border-border/30 bg-card/20 px-6 backdrop-blur-sm transition-all hover:border-primary/30"
                  >
                    <AccordionTrigger className="text-left hover:text-primary transition-colors">
                      Quanto tempo leva para implementar uma automação com IA?
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground leading-relaxed">
                      Normalmente entregamos projetos completos em até 12 dias úteis. Projetos mais simples podem ser
                      implementados em menos tempo, enquanto soluções mais complexas podem levar algumas semanas. Tudo
                      depende do escopo e da integração necessária com seus sistemas existentes.
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem
                    value="item-2"
                    className="rounded-lg border border-border/30 bg-card/20 px-6 backdrop-blur-sm transition-all hover:border-primary/30"
                  >
                    <AccordionTrigger className="text-left hover:text-primary transition-colors">
                      Como a Avanty pode ajudar o meu negócio especificamente?
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground leading-relaxed">
                      Começamos com uma análise gratuita dos seus processos atuais. Identificamos gargalos, tarefas
                      repetitivas e oportunidades de automação. Depois, criamos um roadmap personalizado mostrando
                      exatamente como a IA pode economizar tempo, reduzir custos e aumentar a produtividade no seu
                      contexto específico.
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem
                    value="item-3"
                    className="rounded-lg border border-border/30 bg-card/20 px-6 backdrop-blur-sm transition-all hover:border-primary/30"
                  >
                    <AccordionTrigger className="text-left hover:text-primary transition-colors">
                      Preciso ter conhecimento técnico para usar as soluções?
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground leading-relaxed">
                      Não! Desenvolvemos soluções intuitivas e fáceis de usar. Além disso, fornecemos treinamento
                      completo para sua equipe e suporte contínuo. Nosso objetivo é que você foque no seu negócio, não
                      em tecnologia.
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem
                    value="item-4"
                    className="rounded-lg border border-border/30 bg-card/20 px-6 backdrop-blur-sm transition-all hover:border-primary/30"
                  >
                    <AccordionTrigger className="text-left hover:text-primary transition-colors">
                      Qual é a garantia oferecida?
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground leading-relaxed">
                      Oferecemos 30 dias de garantia total após a implementação. Se os resultados não atenderem suas
                      expectativas ou se você não estiver satisfeito por qualquer motivo, devolvemos 100% do
                      investimento. Além disso, fornecemos suporte técnico contínuo e otimizações sem custo adicional
                      durante o período de garantia.
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem
                    value="item-5"
                    className="rounded-lg border border-border/30 bg-card/20 px-6 backdrop-blur-sm transition-all hover:border-primary/30"
                  >
                    <AccordionTrigger className="text-left hover:text-primary transition-colors">
                      A IA funciona no meu tipo de negócio?
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground leading-relaxed">
                      Sim! Já implementamos soluções em diversos setores: e-commerce, serviços, indústria, saúde,
                      educação e muito mais. A IA é versátil e pode ser adaptada para praticamente qualquer tipo de
                      negócio que tenha processos repetitivos ou que precise escalar operações.
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem
                    value="item-6"
                    className="rounded-lg border border-border/30 bg-card/20 px-6 backdrop-blur-sm transition-all hover:border-primary/30"
                  >
                    <AccordionTrigger className="text-left hover:text-primary transition-colors">
                      Quanto custa implementar IA na minha empresa?
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground leading-relaxed">
                      O investimento varia conforme a complexidade e escopo do projeto. Oferecemos uma análise gratuita
                      onde apresentamos um orçamento detalhado e transparente, junto com a projeção de ROI. A maioria
                      dos nossos clientes recupera o investimento em menos de 6 meses através da economia gerada.
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </AnimatedSection>
            </div>
          </div>
        </section>

        <section id="contato" className="py-16 md:py-24 bg-gradient-to-b from-transparent to-primary/5">
          <div className="container mx-auto px-4 md:px-6">
            <AnimatedSection className="mx-auto max-w-5xl text-center">
              <h2 className="mb-6 md:mb-8 text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold">
                Pronto para <span className="text-primary">Transformar</span> seu Negócio?
              </h2>
              <p className="mb-8 md:mb-12 text-base md:text-xl lg:text-2xl text-muted-foreground max-w-3xl mx-auto px-4">
                Agende uma análise gratuita e descubra como a IA pode revolucionar seus processos e multiplicar seus
                resultados.
              </p>

              <div className="mb-12 md:mb-16 px-4">
                <Button
                  size="lg"
                  asChild
                  className="group bg-primary text-primary-foreground hover:bg-primary/90 transition-all text-base md:text-lg px-8 md:px-10 py-6 md:py-7 h-auto hover:scale-105 hover:shadow-2xl hover:shadow-primary/30 w-full sm:w-auto"
                >
                  <a href="https://wa.me/5531975019782" target="_blank" rel="noopener noreferrer">
                    Agendar Análise Gratuita
                    <ArrowRight className="ml-2 h-5 w-5 md:h-6 md:w-6 transition-transform group-hover:translate-x-1" />
                  </a>
                </Button>
              </div>

              <div className="grid gap-4 md:gap-6 sm:grid-cols-2 lg:grid-cols-3 max-w-4xl mx-auto">
                <AnimatedSection delay={100}>
                  <Card className="group border-border/30 bg-card/30 backdrop-blur-sm transition-all duration-300 hover:border-primary/50 hover:scale-105 hover:shadow-xl hover:shadow-primary/10">
                    <CardContent className="p-8">
                      <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 transition-colors group-hover:bg-primary/20">
                        <MessageCircle className="h-7 w-7 text-primary" />
                      </div>
                      <h3 className="mb-3 text-xl font-bold">WhatsApp</h3>
                      <p className="text-sm text-muted-foreground mb-4">Resposta rápida e atendimento personalizado</p>
                      <Button
                        asChild
                        variant="outline"
                        className="w-full border-primary/30 hover:bg-primary/10 hover:border-primary transition-all bg-transparent"
                      >
                        <a href="https://wa.me/5531975019782" target="_blank" rel="noopener noreferrer">
                          Chamar no WhatsApp
                        </a>
                      </Button>
                    </CardContent>
                  </Card>
                </AnimatedSection>

                <AnimatedSection delay={200}>
                  <Card className="group border-border/30 bg-card/30 backdrop-blur-sm transition-all duration-300 hover:border-primary/50 hover:scale-105 hover:shadow-xl hover:shadow-primary/10">
                    <CardContent className="p-8">
                      <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 transition-colors group-hover:bg-primary/20">
                        <Instagram className="h-7 w-7 text-primary" />
                      </div>
                      <h3 className="mb-3 text-xl font-bold">Instagram</h3>
                      <p className="text-sm text-muted-foreground mb-4">Conteúdos exclusivos e cases de sucesso</p>
                      <Button
                        asChild
                        variant="outline"
                        className="w-full border-primary/30 hover:bg-primary/10 hover:border-primary transition-all bg-transparent"
                      >
                        <a href="https://www.instagram.com/avantysolutions/" target="_blank" rel="noopener noreferrer">
                          Seguir no Instagram
                        </a>
                      </Button>
                    </CardContent>
                  </Card>
                </AnimatedSection>

                <AnimatedSection delay={300}>
                  <Card className="group border-border/30 bg-card/30 backdrop-blur-sm transition-all duration-300 hover:border-primary/50 hover:scale-105 hover:shadow-xl hover:shadow-primary/10">
                    <CardContent className="p-8">
                      <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 transition-colors group-hover:bg-primary/20">
                        <Mail className="h-7 w-7 text-primary" />
                      </div>
                      <h3 className="mb-3 text-xl font-bold">Email</h3>
                      <p className="text-sm text-muted-foreground mb-4">Para propostas e parcerias comerciais</p>
                      <Button
                        onClick={copyEmail}
                        variant="outline"
                        className="w-full border-primary/30 hover:bg-primary/10 hover:border-primary transition-all bg-transparent"
                      >
                        {copiedEmail ? "Email Copiado!" : "Copiar Email"}
                      </Button>
                    </CardContent>
                  </Card>
                </AnimatedSection>
              </div>
            </AnimatedSection>
          </div>
        </section>

        <footer className="border-t border-border/30 bg-background py-8 md:py-12">
          <div className="container mx-auto px-4 md:px-6">
            <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
              <div className="flex items-center gap-2">
                <div className="relative h-6 w-6 md:h-8 md:w-8">
                  <Image src="/logo.png" alt="Avanty Solutions" fill className="object-contain" />
                </div>
                <span className="text-base md:text-lg font-bold">Avanty Solutions</span>
              </div>

              <div className="text-xs md:text-sm text-muted-foreground text-center">
                © 2025 Avanty Solutions. Todos os direitos reservados.
              </div>

              <div className="flex gap-6">
                <a
                  href="https://www.instagram.com/avantysolutions/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground transition-all hover:text-primary hover:scale-125"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a
                  href="https://wa.me/5531975019782"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground transition-all hover:text-primary hover:scale-125"
                >
                  <MessageCircle className="h-5 w-5" />
                </a>
                <a
                  href="mailto:contato.avantysolutions@gmail.com"
                  className="text-muted-foreground transition-all hover:text-primary hover:scale-125"
                >
                  <Mail className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}

"use client"

import { useEffect, useState } from "react"
import Image from "next/image"

export function SplashScreen() {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    // Hide splash screen after 2.5 seconds
    const timer = setTimeout(() => {
      setIsVisible(false)
    }, 2500)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    // Wait for splash screen to fully fade out, then scroll
    const scrollTimer = setTimeout(() => {
      const nossoTrabalhoSection = document.getElementById("nosso-trabalho")
      if (nossoTrabalhoSection) {
        nossoTrabalhoSection.scrollIntoView({ behavior: "smooth", block: "start" })
      }
    }, 3200) // 2500ms splash + 700ms fade out

    return () => clearTimeout(scrollTimer)
  }, [])

  if (!isVisible) return null

  return (
    <div
      className={`fixed inset-0 z-[100] flex items-center justify-center bg-black transition-opacity duration-700 ${
        isVisible ? "opacity-100" : "opacity-0 pointer-events-none"
      }`}
    >
      <div className="relative h-32 w-32 md:h-40 md:w-40 animate-logo-appear">
        <Image src="/logo.png" alt="Avanty Solutions" fill className="object-contain" priority />
      </div>
    </div>
  )
}

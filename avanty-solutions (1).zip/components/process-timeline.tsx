"use client"

import { useEffect, useRef, useState } from "react"
import { Search, FileText, Rocket, LineChart } from "lucide-react"

const steps = [
  {
    number: 1,
    title: "Diagnóstico",
    description: "Analisamos seus processos e identificamos oportunidades de automação com IA",
    icon: Search,
    color: "from-primary/20 to-primary/5",
  },
  {
    number: 2,
    title: "Planejamento",
    description: "Criamos um roadmap personalizado com metas claras e prazos definidos",
    icon: FileText,
    color: "from-primary/30 to-primary/10",
  },
  {
    number: 3,
    title: "Implementação",
    description: "Desenvolvemos e integramos as soluções em até 12 dias úteis",
    icon: Rocket,
    color: "from-primary/40 to-primary/15",
  },
  {
    number: 4,
    title: "Otimização",
    description: "Acompanhamos resultados e otimizamos continuamente para máximo ROI",
    icon: LineChart,
    color: "from-primary/50 to-primary/20",
  },
]

export function ProcessTimeline() {
  const [activeStep, setActiveStep] = useState(0)
  const timelineRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const interval = setInterval(() => {
              setActiveStep((prev) => (prev < steps.length - 1 ? prev + 1 : prev))
            }, 1500)
            return () => clearInterval(interval)
          }
        })
      },
      { threshold: 0.5 },
    )

    if (timelineRef.current) {
      observer.observe(timelineRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <div ref={timelineRef} className="relative">
      {/* Desktop Timeline */}
      <div className="hidden lg:block">
        <div className="relative">
          {/* Connecting Line */}
          <div className="absolute left-0 right-0 top-1/2 h-1 bg-gradient-to-r from-border via-primary/30 to-border -translate-y-1/2" />
          <div
            className="absolute left-0 top-1/2 h-1 bg-gradient-to-r from-primary via-primary to-primary/50 -translate-y-1/2 transition-all duration-1000 ease-out"
            style={{ width: `${(activeStep / (steps.length - 1)) * 100}%` }}
          />

          <div className="grid grid-cols-4 gap-8">
            {steps.map((step, index) => {
              const Icon = step.icon
              const isActive = index <= activeStep
              return (
                <div
                  key={step.number}
                  className="relative flex flex-col items-center"
                  onMouseEnter={() => setActiveStep(index)}
                >
                  {/* Step Circle */}
                  <div
                    className={`relative z-10 mb-6 flex h-24 w-24 items-center justify-center rounded-full border-4 transition-all duration-500 ${
                      isActive
                        ? "border-primary bg-gradient-to-br from-primary/20 to-primary/5 scale-110 shadow-xl shadow-primary/20"
                        : "border-border/30 bg-background/50 scale-100"
                    }`}
                  >
                    <Icon
                      className={`h-10 w-10 transition-all duration-500 ${
                        isActive ? "text-primary scale-110" : "text-muted-foreground scale-100"
                      }`}
                    />
                    <div
                      className={`absolute -top-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground transition-all duration-500 ${
                        isActive ? "scale-100 opacity-100" : "scale-0 opacity-0"
                      }`}
                    >
                      {step.number}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="text-center">
                    <h3
                      className={`mb-3 text-xl font-bold transition-colors duration-500 ${
                        isActive ? "text-primary" : "text-foreground"
                      }`}
                    >
                      {step.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Mobile Timeline */}
      <div className="lg:hidden space-y-6">
        {steps.map((step, index) => {
          const Icon = step.icon
          const isActive = index <= activeStep
          return (
            <div key={step.number} className="relative flex gap-6" onClick={() => setActiveStep(index)}>
              {/* Vertical Line */}
              {index < steps.length - 1 && (
                <div className="absolute left-10 top-20 bottom-0 w-1 bg-gradient-to-b from-border to-transparent" />
              )}
              {index < steps.length - 1 && isActive && (
                <div className="absolute left-10 top-20 bottom-0 w-1 bg-gradient-to-b from-primary to-primary/50 transition-all duration-1000" />
              )}

              {/* Step Circle */}
              <div className="relative flex-shrink-0">
                <div
                  className={`flex h-20 w-20 items-center justify-center rounded-full border-4 transition-all duration-500 ${
                    isActive
                      ? "border-primary bg-gradient-to-br from-primary/20 to-primary/5 scale-110 shadow-lg shadow-primary/20"
                      : "border-border/30 bg-background/50 scale-100"
                  }`}
                >
                  <Icon
                    className={`h-8 w-8 transition-all duration-500 ${
                      isActive ? "text-primary scale-110" : "text-muted-foreground scale-100"
                    }`}
                  />
                  <div
                    className={`absolute -top-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground transition-all duration-500 ${
                      isActive ? "scale-100 opacity-100" : "scale-0 opacity-0"
                    }`}
                  >
                    {step.number}
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 pt-2">
                <h3
                  className={`mb-2 text-lg font-bold transition-colors duration-500 ${
                    isActive ? "text-primary" : "text-foreground"
                  }`}
                >
                  {step.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Calculator, TrendingUp, DollarSign, Clock } from "lucide-react"

export function ROICalculator() {
  const [employees, setEmployees] = useState([5])
  const [hoursPerWeek, setHoursPerWeek] = useState([8])
  const [hourlyRate, setHourlyRate] = useState([50])

  const automationEfficiency = 0.7 // 70% of manual tasks can be realistically automated

  // Calculate actual hours saved considering automation efficiency
  const weeklyHoursSaved = employees[0] * hoursPerWeek[0] * automationEfficiency
  const weeklyCostSavings = weeklyHoursSaved * hourlyRate[0]
  const monthlySavings = weeklyCostSavings * 4.33 // Average weeks per month
  const yearlySavings = monthlySavings * 12

  // Calculate productivity gain (time freed up for strategic work)
  const monthlyHoursFreed = weeklyHoursSaved * 4.33

  // Base cost + per employee cost + complexity factor
  const baseInvestment = 3000
  const perEmployeeCost = employees[0] * 400
  const complexityFactor = hoursPerWeek[0] > 20 ? 2000 : hoursPerWeek[0] > 10 ? 1000 : 0
  const estimatedInvestment = baseInvestment + perEmployeeCost + complexityFactor

  const paybackMonths = monthlySavings > 0 ? Math.ceil(estimatedInvestment / monthlySavings) : 0
  const roi = monthlySavings > 0 ? ((yearlySavings - estimatedInvestment) / estimatedInvestment) * 100 : 0

  return (
    <Card className="border-primary/30 bg-card/40 backdrop-blur-sm">
      <CardContent className="p-6 md:p-8">
        <div className="mb-6 flex items-center gap-3">
          <Calculator className="h-5 w-5 md:h-6 md:w-6 text-primary" />
          <h3 className="text-xl md:text-2xl font-bold">Calcule sua Economia</h3>
        </div>

        <div className="space-y-6">
          <div>
            <label className="mb-3 block text-sm font-medium">Quantos funcionários executam tarefas repetitivas?</label>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs text-muted-foreground">1 pessoa</span>
              <span className="text-lg md:text-xl font-bold text-primary">
                {employees[0]} {employees[0] === 1 ? "pessoa" : "pessoas"}
              </span>
              <span className="text-xs text-muted-foreground">50 pessoas</span>
            </div>
            <Slider
              value={employees}
              onValueChange={setEmployees}
              min={1}
              max={50}
              step={1}
              className="cursor-pointer"
            />
          </div>

          <div>
            <label className="mb-3 block text-sm font-medium">
              Quantas horas por semana são gastas em tarefas manuais?
            </label>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs text-muted-foreground">1h</span>
              <span className="text-lg md:text-xl font-bold text-primary">{hoursPerWeek[0]}h/semana</span>
              <span className="text-xs text-muted-foreground">40h</span>
            </div>
            <Slider
              value={hoursPerWeek}
              onValueChange={setHoursPerWeek}
              min={1}
              max={40}
              step={1}
              className="cursor-pointer"
            />
          </div>

          <div>
            <label className="mb-3 block text-sm font-medium">Qual o custo médio por hora desses profissionais?</label>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs text-muted-foreground">R$ 20</span>
              <span className="text-lg md:text-xl font-bold text-primary">R$ {hourlyRate[0]}/h</span>
              <span className="text-xs text-muted-foreground">R$ 200</span>
            </div>
            <Slider
              value={hourlyRate}
              onValueChange={setHourlyRate}
              min={20}
              max={200}
              step={10}
              className="cursor-pointer"
            />
          </div>

          <div className="mt-8 space-y-4 rounded-lg border border-primary/30 bg-primary/5 p-4 md:p-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="flex items-start gap-3">
                <DollarSign className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Economia Mensal</p>
                  <p className="text-lg md:text-xl font-bold text-primary">
                    R$ {Math.round(monthlySavings).toLocaleString("pt-BR")}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Horas Liberadas/Mês</p>
                  <p className="text-lg md:text-xl font-bold text-primary">{Math.round(monthlyHoursFreed)}h</p>
                </div>
              </div>
            </div>

            <div className="border-t border-primary/20 pt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Economia Anual Projetada:</span>
                <span className="text-2xl md:text-3xl font-bold text-primary">
                  R$ {Math.round(yearlySavings).toLocaleString("pt-BR")}
                </span>
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs text-muted-foreground">
                <span>
                  Investimento estimado:{" "}
                  <span className="text-primary font-semibold">
                    R$ {Math.round(estimatedInvestment).toLocaleString("pt-BR")}
                  </span>
                </span>
                <span>
                  ROI: <span className="text-primary font-semibold">{Math.round(roi)}%</span> | Payback:{" "}
                  <span className="text-primary font-semibold">
                    {paybackMonths} {paybackMonths === 1 ? "mês" : "meses"}
                  </span>
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2 text-xs text-muted-foreground bg-background/50 rounded p-3">
              <TrendingUp className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
              <p>
                Cálculo considera 70% de taxa de automação realista. Investimento varia conforme complexidade dos
                processos. Valores finais dependem de análise detalhada do seu negócio.
              </p>
            </div>
          </div>

          <Button
            asChild
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 transition-all hover:scale-105"
            size="lg"
          >
            <a href="https://wa.me/5531975019782" target="_blank" rel="noopener noreferrer">
              Quero Economizar Agora
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
